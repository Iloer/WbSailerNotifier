﻿namespace WbSailerNotifier.DataAccess.Models
{
    public class GetOrdersFilter
    {
        public bool? IsNotified { get; set; }
    }
}
