# WbSailerNotifier

Build
```
docker build -t wb-sailer-notifier .
```